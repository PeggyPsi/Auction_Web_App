import { BidCheckValidator } from "./bid-check.validator";


describe('BidCheckValidator', () => {
  it('should create an instance', () => {
    expect(new BidCheckValidator()).toBeTruthy();
  });
});
