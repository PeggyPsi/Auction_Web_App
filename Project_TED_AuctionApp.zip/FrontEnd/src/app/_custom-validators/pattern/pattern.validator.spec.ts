import { PatternValidator } from './pattern.validator';

describe('Pattern.Validator', () => {
  it('should create an instance', () => {
    expect(new PatternValidator()).toBeTruthy();
  });
});
