import { FixedLengthValidator } from "./fixed-length.validator";


describe('FixedLengthValidator', () => {
  it('should create an instance', () => {
    expect(new FixedLengthValidator()).toBeTruthy();
  });
});
