import { EndStartDateValidator } from './end-start-date.validator';

describe('EndStartDateValidator', () => {
  it('should create an instance', () => {
    expect(new EndStartDateValidator()).toBeTruthy();
  });
});
