import { PasswordMatchValidator } from './password-match.validator';

describe('PasswordMatch.Validator', () => {
  it('should create an instance', () => {
    expect(new PasswordMatchValidator()).toBeTruthy();
  });
});
