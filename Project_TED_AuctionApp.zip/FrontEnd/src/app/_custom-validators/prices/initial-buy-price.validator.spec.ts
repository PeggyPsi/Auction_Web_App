import { InitialBuyPriceValidator } from './initial-buy-price.validator';

describe('EndStartDateValidator', () => {
  it('should create an instance', () => {
    expect(new InitialBuyPriceValidator()).toBeTruthy();
  });
});
