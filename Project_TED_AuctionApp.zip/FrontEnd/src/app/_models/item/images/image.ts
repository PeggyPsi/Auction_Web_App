export class Image {
    id: number;
    name: string;
    content: any;
}
