import { Bid } from './bid';

describe('Bid', () => {
  it('should create an instance', () => {
    expect(new Bid()).toBeTruthy();
  });
});
