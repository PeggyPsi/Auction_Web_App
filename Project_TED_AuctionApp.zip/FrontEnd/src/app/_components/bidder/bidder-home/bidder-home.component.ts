import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bidder-home',
  templateUrl: './bidder-home.component.html',
  styleUrls: ['./bidder-home.component.css']
})
export class BidderHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
