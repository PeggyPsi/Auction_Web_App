import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-refresh-page',
  templateUrl: './refresh-page.component.html',
  styleUrls: ['./refresh-page.component.css']
})
export class RefreshPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
