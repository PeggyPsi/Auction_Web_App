import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-server-connection',
  templateUrl: './error-server-connection.component.html',
  styleUrls: ['./error-server-connection.component.css']
})
export class ErrorServerConnectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
