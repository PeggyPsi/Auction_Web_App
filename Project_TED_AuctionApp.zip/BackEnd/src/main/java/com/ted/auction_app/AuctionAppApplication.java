package com.ted.auction_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuctionAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuctionAppApplication.class, args);
    }

}
