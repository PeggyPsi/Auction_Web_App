package com.ted.auction_app.Utils;

// TODO Check whether you need this kind of file or not
public class Constants {
    //Security Constants
    public static final String BEARER_TOKEN= "Bearer ";
    public static final String HEADER= "authorization";
    public static final String ISSUER= "ducat-springboot-jwttoken";
    public static final String SECRET_KEY= "Springbootjwttutorial";
}
