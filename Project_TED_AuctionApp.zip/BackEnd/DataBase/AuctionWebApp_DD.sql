-- SQL script for the deletion of auction web application database
DROP DATABASE IF EXISTS AuctionWebApp;    -- Delete database
DROP USER IF EXISTS 'app_user'@'%';       -- Delete custom user
